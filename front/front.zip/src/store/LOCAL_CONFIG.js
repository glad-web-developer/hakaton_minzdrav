let baseUrl = 'http://127.0.0.1:8000';
// let baseUrl = '';
export default {
    baseUrl: baseUrl,

    urls: {
        pregnant: `${baseUrl}/api/beremennaya/`,

        // пользователь
        login: `${baseUrl}/api/login/`,
        checkUser: `${baseUrl}/api/check_user/`,
        logout: `${baseUrl}/api/logout/`,
    },



}