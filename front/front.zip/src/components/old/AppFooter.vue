<template>
  <footer class="bg-dark pt-2">
    <div class="text-white text-center">
      <b>Разработка <a class="text-danger text-decoration-none" href="https://vk.com/glad_web_developer">Гладких
        К.А.</a></b></div>
  </footer>
</template>

<script>
export default {
  name: "AppFooter"
}
</script>

<style scoped>

</style>