<template>
<div>
  <pregnant-data-table/>
</div>
</template>

<script>
import PregnantDataTable from "@/components/PregnantDataTable";
export default {
  name: "HomeView",
  components: {
    PregnantDataTable,
  },
}
</script>

<style scoped>

</style>