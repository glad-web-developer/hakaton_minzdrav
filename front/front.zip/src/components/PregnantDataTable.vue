<template>
  <v-data-table
      :headers="headers"
      :items="pregnants"
      :items-per-page="5"
      class="elevation-1"
  ></v-data-table>
</template>

<script>


import LOCAL_CONFIG from "@/store/LOCAL_CONFIG";
import CookieHelper from "@/plugins/cookieHelper";

export default {
  name: "PregnantDataTable",
  data() {
    return {
      headers: [
        // {
        //   text: 'Dessert (100g serving)',
        //   align: 'start',
        //   sortable: false,
        //   value: 'name',
        // },
        // {text: 'Calories', value: 'calories'},
        // {text: 'Fat (g)', value: 'fat'},
        // {text: 'Carbs (g)', value: 'carbs'},
        // {text: 'Protein (g)', value: 'protein'},
        // {text: 'Iron (%)', value: 'iron'},
      ],
      pregnants: [],
    }
  },

  methods: {
    async getListData() {
      const url = `${LOCAL_CONFIG.urls.pregnant}`;
      // alert(CookieHelper.getCookie('csrftoken'));
      const response = await fetch(url, {
        method: 'post',
        mode: "cors",
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          "Accept": "application/json",
          'X-CSRFToken': CookieHelper.getCookie('csrftoken'),
        },
      });
      this.pregnants = await response.json();
    },
  },

  async created() {
    await this.getListData();
  },
}
</script>

<style scoped>

</style>