<template>
  <div class="position-relative" :class="{'wrap':dialogShow}">
    <v-dialog
        :value="dialogShow"
        persistent
        scrollable
        max-width="1000px"
    >
      <v-card>

        <v-card-title class="text-center bg-light ">
          <div class="h3 ">Продление рекламных программ</div>
          <div class="ms-auto">
            <button class="close-btn" @click="closeDialog">
              <v-icon>
                mdi-close-circle
              </v-icon>
            </button>
          </div>
        </v-card-title>

        <v-card-text>
          <v-card
              color="basil"
              flat
              class="py-3 "
          >
            <v-progress-linear
                indeterminate
                :active="ajaxLoad"
                class="mt-3"
                color="yellow darken-2"
            ></v-progress-linear>

            <v-simple-table
                light
                fixed-header
                height="580px"
                v-if="advertisingProgramHouseList.length > 0"
            >
              <template v-slot:default>
                <thead>
                <tr>
                  <th class="text-left">
                    Рекламная программа
                  </th>
                  <th class="text-left" width="100">
                    Переносить?
                  </th>
                </tr>
                </thead>
                <tbody>
                <tr
                    v-for="item in advertisingProgramHouseList"
                    :key="item.id"
                >
                  <td>
                    11
                  </td>
                  <td>
                   12

                  </td>

                </tr>
                </tbody>
              </template>
            </v-simple-table>

            <v-alert v-else
                     dense
                     icon="mdi-information-outline"
                     text
                     color="orange"
            ><span
                class=" mt-3 text-dark">хмммм... Как странно, но данных нет... А  реклама точно есть? -_-</span>
            </v-alert>

            <v-btn
                color="orange"
                dark
                @click="save"
            >
              <v-icon>mdi mdi-content-save</v-icon>
              Сохранить
            </v-btn>

          </v-card>
        </v-card-text>

      </v-card>
    </v-dialog>

  </div>
</template>

<script>

export default {
  name: "AppAdvertisingProgramProlongWindow",
  data() {
    return {
      ajaxLoad: true,
      dialogShow: false,
      periodBefore: '',
      periodAfter: '',
      advertisingProgramHouseList:[]
    }
  },

  computed: {

  },

  methods: {
    closeDialog: function () {
      this.dialogShow = false;

      this.$emit('closeDialog', {});
    },

    // async geServerData(houseId, period) {
      // this.period = period;
      // this.ajaxLoad = true;
      // const url = `${LOCAL_CONFIG.urls.advertisingProgramEdit}${period}/${houseId}/`;
      // const response = await fetch(url, {method: 'get'});
      // this.changeData = await response.json();
      // this.ajaxLoad = false;
    // },

    async openDialog( periodBefore) {
      this.periodBefore = periodBefore;
      this.dialogShow = true;
    },


    async save() {
      // const url = `${LOCAL_CONFIG.urls.advertisingProgramEdit}${this.period}/${this.houseId}/`;
      // try {
      //   const r = await fetch(url, {
      //     method: 'POST',
      //     body: JSON.stringify(this.changeData),
      //     headers: {
      //       'Content-Type': 'application/json',
      //       'X-CSRFToken': CookieHelper.getCookie('csrftoken')
      //     },
      //   });
      //
      //   if (r.status > 201) {
      //     this.$emit('showAlert', await r.text());
      //   } else {
      //     this.$emit('showAlert', 'Данные сохранены')
      //     this.closeDialog()
      //   }
      // } catch (error) {
      //   this.$emit('showAlert', 'Ошибка при обращение к серверу')
      // }
    }

  }
}
</script>

<style scoped>
/*.theme--light.v-data-table > .v-data-table__wrapper > table > tbody > tr:hover:not(.v-data-table__expanded__content):not(.v-data-table__empty-wrapper) {*/
/*  background: none !important;*/
/*}*/


</style>